//
//  ViewController.m
//  Runtime黑魔法
//
//  Created by piaoguanjia123 on 2019/4/2.
//  Copyright © 2019 piaoguanjia123. All rights reserved.
//

#import "ViewController.h"
#import "SecondViewController.h"
#import "UIView+ExchangeMethod.h"

@interface ViewController ()

@end

@implementation ViewController


-(void)viewDidLoad{
    [super viewDidLoad];
    
    self.view.backgroundColor = [UIColor whiteColor];
    /*测试UIbutton*/
    UIButton *btn = [UIButton new];
    btn =[[UIButton alloc]initWithFrame:CGRectMake(100,100,100,40)];
    [btn setTitle:@"btnTest"forState:UIControlStateNormal];
    [btn setTitleColor:[UIColor redColor]forState:UIControlStateNormal];
    btn.acceptEventInterval = 3;
    [self.view addSubview:btn];
    [btn addTarget:self action:@selector(btnAction)forControlEvents:UIControlEventTouchUpInside];
    
    /*测试String*/
    NSString * str = @"11";
    [str stringByAppendingString:nil];
    NSLog(@"str:%@",str);
}

- (void)btnAction{
    NSLog(@"btnAction is executed");
    /*测试view*/
    [self presentViewController:[[SecondViewController alloc]init] animated:YES completion:nil];
}


@end
