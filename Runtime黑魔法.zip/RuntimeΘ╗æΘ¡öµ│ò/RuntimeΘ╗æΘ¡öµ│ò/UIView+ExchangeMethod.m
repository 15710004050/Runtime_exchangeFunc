//
//  UIView+ExchangeMethod.m
//  测试
//
//  Created by piaoguanjia123 on 2019/4/2.
//  Copyright © 2019 piaoguanjia123. All rights reserved.
//

#import "UIView+ExchangeMethod.h"
#import <objc/runtime.h>

@implementation UIView (ExchangeMethod)
+ (void)load{
    Method func1 = class_getInstanceMethod(self, NSSelectorFromString(@"dealloc"));
    Method func2 = class_getInstanceMethod(self, @selector(wb_dealloc));
    method_exchangeImplementations(func1, func2);
}

- (void)wb_dealloc
{
    NSLog(@"%s--------%s-------%d",class_getName(self.class),__func__,__LINE__);
}

@end

static const char *UIControl_acceptEventInterval="UIControl_acceptEventInterval";
static const char *UIControl_ignoreEvent="UIControl_ignoreEvent";
@implementation UIControl (ExchangeMethod)

#pragma mark - acceptEventInterval
- (void)setAcceptEventInterval:(NSTimeInterval)acceptEventInterval
{
    objc_setAssociatedObject(self,UIControl_acceptEventInterval, @(acceptEventInterval), OBJC_ASSOCIATION_RETAIN_NONATOMIC);
}

-(NSTimeInterval)acceptEventInterval {
    return [objc_getAssociatedObject(self,UIControl_acceptEventInterval) doubleValue];
}

#pragma mark - ignoreEvent
-(void)setIgnoreEvent:(BOOL)ignoreEvent{
    objc_setAssociatedObject(self,UIControl_ignoreEvent, @(ignoreEvent), OBJC_ASSOCIATION_ASSIGN);
}

-(BOOL)ignoreEvent{
    return [objc_getAssociatedObject(self,UIControl_ignoreEvent) boolValue];
}

+ (void)load{
    Method a = class_getInstanceMethod(self,@selector(sendAction:to:forEvent:));
    Method b = class_getInstanceMethod(self,@selector(wb_sendAction:to:forEvent:));
    method_exchangeImplementations(a, b);//交换方法
}
- (void)wb_sendAction:(SEL)action to:(id)target forEvent:(UIEvent*)event
{
    if(self.ignoreEvent){
        NSLog(@"btnAction is intercepted");
        return;}
    NSLog(@"-------%f",self.acceptEventInterval);
    if(self.acceptEventInterval>0){
        self.ignoreEvent=YES;
        [self performSelector:@selector(setIgnoreEventWithNo)  withObject:nil afterDelay:self.acceptEventInterval];
    }
    [self wb_sendAction:action to:target forEvent:event];
}

-(void)setIgnoreEventWithNo{
    self.ignoreEvent=NO;
}

@end

@implementation NSArray (ExchangeMethod)

+ (void)load{
    Method fromMethod = class_getInstanceMethod(objc_getClass("__NSArrayI"), @selector(objectAtIndex:));
    Method toMethod = class_getInstanceMethod(objc_getClass("__NSArrayI"), @selector(wb_objectAtIndex:));
    method_exchangeImplementations(fromMethod, toMethod);
}

-(id )wb_objectAtIndex:(NSUInteger)index{
    if (self.count - 1 < index) {
        @try {
            return [self wb_objectAtIndex:index];
        } @catch (NSException *exception) {
            // 在崩溃后会打印崩溃信息。如果是线上，可以在这里将崩溃信息发送到服务器
            NSLog(@"---------- %s Crash Because Method %s  ----------\n", class_getName(self.class), __func__);
            NSLog(@"%@",[exception callStackSymbols]);
            return nil;
        } @finally {
        }
    }else{
        return [self wb_objectAtIndex:index];
    }
}

@end

@implementation NSString (ExchangeMethod)
+ (void)load{
    Method func1 = class_getInstanceMethod(self, @selector(stringByAppendingString:));
    Method func2 = class_getInstanceMethod(self, @selector(wb_stringByAppendingString:));
    method_exchangeImplementations(func1, func2);
}

- (NSString *)wb_stringByAppendingString:(NSString *)aString{
    if (aString == nil || aString.length == 0) {
        @try {
            return [self wb_stringByAppendingString:aString];
        } @catch (NSException *exception) {
            // 在崩溃后会打印崩溃信息。如果是线上，可以在这里将崩溃信息发送到服务器
            NSLog(@"---------- %s Crash Because Method %s  ----------\n", class_getName(self.class), __func__);
            NSLog(@"%@",[exception callStackSymbols]);
            return nil;
        } @finally {
        }
    }else{
       return [self wb_stringByAppendingString:aString];
    }
}
@end

